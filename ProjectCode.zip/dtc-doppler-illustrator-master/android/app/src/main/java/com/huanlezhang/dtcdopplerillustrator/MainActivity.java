package com.huanlezhang.dtcdopplerillustrator;

import android.Manifest;
import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Button;

import org.apache.commons.math3.ml.neuralnet.twod.util.LocationFinder;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.io.File;
import java.util.Locale;
import java.util.UUID;

/**
 * Illustrating Doppler effect
 *
 * @author Huanle Zhang, University of California, Davis
 *          www.huanlezhang.com
 * @version 0.2
 * @since 2019-07-11
 */

public class MainActivity extends Activity{
    Button btnGetLoc;

    MediaRecorder mediaRecorder;
    Button btnRecord,btnStopRecord,btnPlay,btnStop;
    String pathSave = "";
    MediaPlayer mediaPlayer;
    private Chronometer timer;

    final int REQUEST_PERMISSION_CODE=1000;




    private static final String[] PermissionStrings = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.INTERNET
    };


    private static final int Permission_ID = 1;

    private RadioGroup mRadioGroup;

    private boolean mIsSender;

    private ToggleButton mMainToggleBtn;

    private ImageView mImageView;
    private int mImageViewWidth;
    private int mImageViewHeight;

    private Bitmap mBitmap;
    private Canvas mCanvas;
    private Paint mPaint;
    private Paint mBaseLinePaint;

    // for sender
    PlaySound mPlaySound = new PlaySound();
    private final int FREQ_SOUND = 19000;   // emit 19 KHz sounds

    // for receiver
    private Handler mHandler = new Handler();
    private Runnable mDrawFFTRun = new DrawFFT();

    private AnalyzeFrequency mFftAnalysis;
    private final int N_FFT_DOT = 4096;
    private float[] mCurArray = new float[N_FFT_DOT / 2 - 1];
    private static final int FREQ_OFFSET_MAX = 20;  // maximum frequency range

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        if(!checkPermissionFromDevice())
            requestPermission();

        //chronometer
        timer= (Chronometer)findViewById(R.id.record_timer);

        //code for audio recording
        btnPlay= (Button)findViewById(R.id.btnPlay);
        btnRecord= (Button)findViewById(R.id.btnStartRecord);
        btnStop= (Button)findViewById(R.id.btnStop);
        btnStopRecord= (Button)findViewById(R.id.btnStopRecord);



            btnRecord.setOnClickListener(new View.OnClickListener()
            {

                    @Override
                    public void onClick(View view) {
                        if(checkPermissionFromDevice())
                        {
                            timer.start();
                            timer.setBase(SystemClock.elapsedRealtime());
                            SimpleDateFormat formatter=new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss", Locale.US);
                            Date now=new Date();
                    pathSave = Environment.getExternalStorageDirectory()
                            .getAbsolutePath()+"/"+
                            "Recording"+formatter.format(now)+".3gp";
                    setupMediaRecorder();
                    try{
                        mediaRecorder.prepare();
                        mediaRecorder.start();
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                    btnPlay.setEnabled(false);
                    btnStop.setEnabled(false);
                    Toast.makeText(MainActivity.this,"Recording ...",Toast.LENGTH_SHORT).show();
                    }

                    else
                    {

                        requestPermission();
                    }
                }
            });

            btnStopRecord.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view) {
                    timer.stop();
                    mediaRecorder.stop();
                    btnStopRecord.setEnabled(false);
                    btnPlay.setEnabled(true);
                    btnRecord.setEnabled(true);
                    btnStop.setEnabled(false);
                }
            });

            btnPlay.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view) {
                    btnStop.setEnabled(true);
                    btnStopRecord.setEnabled(false);
                    btnRecord.setEnabled(false);

                    mediaPlayer = new MediaPlayer();
                    try{
                        mediaPlayer.setDataSource(pathSave);
                        mediaPlayer.prepare();
                    }catch (IOException e){
                        e.printStackTrace();
                    }

                    mediaPlayer.start();
                    Toast.makeText(MainActivity.this,"Playing...",Toast.LENGTH_SHORT).show();
                }
            });

            btnStop.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view) {
                    btnStopRecord.setEnabled(true);
                    btnRecord.setEnabled(true);
                    btnStop.setEnabled(true);
                    btnPlay.setEnabled(true);

                    if(mediaPlayer != null)
                    {
                        mediaPlayer.stop();
                        mediaPlayer.release();
                        setupMediaRecorder();
                    }
                }
            });






        TextView textView=findViewById(R.id.date);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
        String currentDateandTime = sdf.format(new Date());
        textView.setText(currentDateandTime);


        btnGetLoc = findViewById(R.id.btnGetLoc);
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);

        btnGetLoc.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                GPStracker g=new GPStracker(getApplicationContext());
                Location l=g.getLocation();
                if(l!=null){
                    double lat=l.getLatitude();
                    double lon=l.getLongitude();
                    Toast.makeText(getApplicationContext(),"LAT:"+lat+"\n LON:"+lon,Toast.LENGTH_LONG).show();
                }

            }
        });


        ActivityCompat.requestPermissions(this, PermissionStrings, Permission_ID);

        mRadioGroup = findViewById(R.id.radioGroup);

        mMainToggleBtn = findViewById(R.id.startToggleBtn);
        mMainToggleBtn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                ToggleButton toggleButton = (ToggleButton) v;
                if (toggleButton.isChecked()) {
                    startMain();
                } else {
                    stopMain();
                }
            }
        });


        // set up the imageview
        mImageView = findViewById(R.id.mainImageView);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        mImageViewWidth = displayMetrics.widthPixels - (int) (getResources().getDisplayMetrics().density * 4.0 + 0.5);
        mImageViewHeight = mImageViewWidth; // a square view
        mBitmap = Bitmap.createBitmap(mImageViewWidth, mImageViewHeight, Bitmap.Config.ARGB_4444);
        mCanvas = new Canvas(mBitmap);
        mCanvas.drawColor(Color.LTGRAY);
        mPaint = new Paint();
        mPaint.setColor(Color.BLACK);
        mPaint.setStrokeWidth(10);
        mBaseLinePaint = new Paint();
        mBaseLinePaint.setColor(Color.BLUE);
        mBaseLinePaint.setStrokeWidth(5);
        mImageView.setImageBitmap(mBitmap);
        mImageView.invalidate();

        TextView maxFreqText = findViewById(R.id.maxFreq);
        maxFreqText.setText(FREQ_OFFSET_MAX + " Hz");
        TextView minFreqText = findViewById(R.id.minFreq);
        minFreqText.setText(-FREQ_OFFSET_MAX + " Hz");
    }

    private void setupMediaRecorder(){
        mediaRecorder= new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        mediaRecorder.setOutputFile(pathSave);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private boolean checkPermissionFromDevice(){
        int write_external_storage_result= ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int record_audio_result= ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO);
        return write_external_storage_result == PackageManager.PERMISSION_GRANTED &&
                record_audio_result == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission(){
        ActivityCompat.requestPermissions(this,new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION
        },REQUEST_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case REQUEST_PERMISSION_CODE:
            {
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(this,"Permission Granted",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(this,"Permission Denied",Toast.LENGTH_SHORT).show();
            }
            break;
        }
    }

    void startMain() {
        enableAllUI(false);
        mMainToggleBtn.setEnabled(true);
        int radioBtnId = mRadioGroup.getCheckedRadioButtonId();
        if (radioBtnId == R.id.senderRadio) {
            // sender
            mIsSender = true;
            mPlaySound = new PlaySound();
            mPlaySound.mOutputFreq = FREQ_SOUND;
            mPlaySound.start();
        } else {
            // receiver
            mIsSender = false;
            mFftAnalysis = new AnalyzeFrequency(mHandler, mDrawFFTRun);
            mFftAnalysis.start();
        }
    }

    void stopMain() {
        enableAllUI(true);
        if (mIsSender) {
            if (mPlaySound != null) {
                mPlaySound.stop();
                mPlaySound = null;
            }
        } else {
            if (mFftAnalysis != null) {
                mFftAnalysis.stop();
                mFftAnalysis = null;
            }
            Arrays.fill(mCurArray, (float) 0.0);
        }
    }

    void enableAllUI(boolean enable) {
        // for radio group
        for (int i = 0; i < mRadioGroup.getChildCount(); i++) {
            mRadioGroup.getChildAt(i).setEnabled(enable);
        }

        mMainToggleBtn.setEnabled(enable);
    }

    // draw doppler on screen
    public class DrawFFT implements Runnable {
        @Override
        public void run() {
            if (mFftAnalysis == null) {
                return;
            }
            int scaleFFT = (mImageViewHeight / 2) / FREQ_OFFSET_MAX;
            int N_CH_DOT = mFftAnalysis.N_CH_DOT;
            int fftInterval = (int) (1.0 * mImageViewWidth / N_CH_DOT);
            int fftDisplayRange = fftInterval * N_CH_DOT;
            int index = (mFftAnalysis.mChIndex - 1) % N_CH_DOT;

            mCanvas.drawColor(Color.LTGRAY);

            // horizontal base line
            mCanvas.drawLine(0, mImageViewHeight / 2, mImageViewWidth, mImageViewHeight / 2, mBaseLinePaint);

            for (int i = fftDisplayRange; i > fftInterval; i -= fftInterval) {
                mCanvas.drawLine(i, mImageViewHeight / 2 - scaleFFT * mFftAnalysis.mCh[(index + 2 * N_CH_DOT) % N_CH_DOT],
                        i - fftInterval, mImageViewHeight / 2 - scaleFFT * mFftAnalysis.mCh[(index + 2 * N_CH_DOT - 1) % N_CH_DOT],
                        mPaint);
                --index;
            }
            mImageView.invalidate();
        }
    }

 }
